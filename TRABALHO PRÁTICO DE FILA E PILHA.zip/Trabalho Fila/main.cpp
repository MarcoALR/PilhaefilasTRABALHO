/*

    ESPECIFICA��O DO TRABALHO PR�TICO DE FILA E PILHA

    Aluno UNIFAGOC: Marco Ant�nio Lopes Ribeiro

    Objetivo do Programa:
    O programa recebe entradas de matriculas e notas de alunos fornecidas pelo usuario, armazena os dados em uma fila
    e depois transfere para uma pilha de forma ordenada pela nota. Ap�s isso, os dados s�o desempilhados e exibidos na tela.

    Como deve ser feita a entrada de dados:
    O usuario deve inserir a matricula (numero inteiro) e a nota (numero decimal) dos alunos. Para encerrar a entrada de dados,
    deve-se digitar "-1" como matricula.

    Resultado da Execucao do Programa:
    O programa exibe a lista de alunos com suas notas em ordem decrescente de nota. Em caso de empate, as matriculas sao usadas como criterio de desempate.

*/

#include <iostream>    // Biblioteca padrao para entrada e saida de dados.
#include "Fila.h"      // Inclui o arquivo de cabecalho da classe Fila (implementacao de fila).
#include "Pilha.h"     // Inclui o arquivo de cabecalho da classe Pilha (implementacao de pilha).

using namespace std;    // Permite o uso direto de elementos do namespace std, como cout e cin.

// Funcao para ler dados (matricula e nota) e enfileirar na fila.
void Ler(Fila &fila)
{
    int matricula;
    float nota;

    // Solicita ao usuario a matricula do aluno (ou -1 para encerrar a leitura).
    cout << "Digite a matricula do aluno (ou -1 para Encerrar o Programa): ";
    cin >> matricula;

    // Laco que continua ate que o usuario digite -1 para encerrar.
    while (matricula != -1)
    {
        // Solicita a nota do aluno.
        cout << "Digite a nota do aluno: ";
        cin >> nota;

        // Enfileira a matricula e a nota na fila.
        fila.Enfileirar(matricula, nota);

        // Solicita a matricula do proximo aluno ou -1 para encerrar.
        cout << "Digite a matricula do proximo aluno (ou -1 para terminar): ";
        cin >> matricula;
    }
}

// Funcao que transfere os dados da fila para a pilha, mantendo-os ordenados pela nota.
void TransferirParaPilha(Fila &fila, Pilha &pilha)
{
    int matricula;
    float nota;

    // Enquanto a fila nao estiver vazia, desenfileira os elementos e os empilha de forma ordenada.
    while (!fila.Vazia())
    {
        fila.Desenfileirar(matricula, nota);
        pilha.EmpilharOrdenado(matricula, nota);  // Empilha os elementos mantendo a ordem pela nota.
    }
}

// Funcao principal.
int main()
{
    Fila fila;    // Cria uma fila para armazenar as matriculas e notas dos alunos.
    Pilha pilha;  // Cria uma pilha para armazenar os dados de forma ordenada.

    // Chama a funcao Ler para enfileirar os dados.
    Ler(fila);

    // Transfere os dados da fila para a pilha, mantendo a ordem pela nota.
    TransferirParaPilha(fila, pilha);

    int matricula;
    float nota;

    // Exibe os dados desempilhados na ordem desejada.
    cout << "\nDados desempilhados (em ordem de nota):" << endl;
    while (!pilha.Vazia())
    {
        pilha.Desempilhar(matricula, nota);  // Desempilha o proximo elemento.
        // Exibe a matricula e a nota do aluno.
        cout << "Matricula: " << matricula << ", Nota: " << nota << endl;
    }

    return 0;    // Indica que o programa terminou com sucesso.
}

#include "Fila.h"       // Inclui o cabe�alho da classe Fila.
#include <iostream>     // Biblioteca padr�o para entrada e sa�da de dados.

// Construtor da classe Fila: inicializa os ponteiros Frente e Tras como nullptr e o tamanho da fila como 0.
Fila::Fila()
{
    Frente = nullptr;
    Tras = nullptr;
    Tamanho = 0;
}

// Destrutor da classe Fila: libera a mem�ria de todas as c�lulas (n�s) da fila.
Fila::~Fila()
{
    TipoCelulaFila *aux;
    // Enquanto houver c�lulas na fila, desaloca a mem�ria de cada uma.
    while (Frente != nullptr)
    {
        aux = Frente;             // Armazena o ponteiro da c�lula da frente.
        Frente = Frente->Prox;    // Move o ponteiro Frente para o pr�ximo n�.
        delete aux;               // Libera a c�lula anterior da mem�ria.
    }
    Tras = nullptr;               // Garante que o ponteiro Tras fique nulo.
}

// Verifica se a fila est� vazia (retorna true se a fila estiver vazia, ou seja, se o ponteiro Frente for nullptr).
bool Fila::Vazia()
{
    return (Frente == nullptr);
}

// Retorna o tamanho atual da fila (quantidade de elementos).
int Fila::GetTamanho()
{
    return Tamanho;
}

// Fun��o para enfileirar um novo elemento (matr�cula e nota) na fila.
bool Fila::Enfileirar(TipoDado Matricula, float Nota)
{
    // Cria uma nova c�lula (n�) da fila.
    TipoCelulaFila *nova = new TipoCelulaFila;
    nova->Matricula = Matricula;    // Atribui a matr�cula ao novo n�.
    nova->Nota = Nota;              // Atribui a nota ao novo n�.
    nova->Prox = nullptr;           // O pr�ximo n� � inicialmente nulo.

    // Se a fila estiver vazia, o novo n� ser� o primeiro elemento (Frente).
    if (Vazia())
    {
        Frente = nova;
    }
    else
    {
        // Caso contr�rio, o novo n� ser� colocado ap�s o n� que est� no fim da fila (Tras).
        Tras->Prox = nova;
    }

    Tras = nova;       // Atualiza o ponteiro Tras para apontar para o novo �ltimo n�.
    Tamanho++;         // Incrementa o tamanho da fila.
    return true;       // Retorna true indicando que o enfileiramento foi bem-sucedido.
}

// Fun��o para desenfileirar (remover) o elemento da frente da fila.
bool Fila::Desenfileirar(TipoDado &Matricula, float &Nota)
{
    // Verifica se a fila est� vazia. Se estiver, retorna false.
    if (Vazia()) return false;

    // Armazena o ponteiro da c�lula que est� na frente da fila.
    TipoCelulaFila *aux = Frente;
    Matricula = aux->Matricula;    // Obt�m a matr�cula do n� a ser removido.
    Nota = aux->Nota;              // Obt�m a nota do n� a ser removido.
    Frente = Frente->Prox;         // Atualiza o ponteiro Frente para o pr�ximo n�.

    // Se ap�s a remo��o a fila estiver vazia, o ponteiro Tras tamb�m deve ser nulo.
    if (Frente == nullptr)
    {
        Tras = nullptr;
    }

    delete aux;      // Libera a c�lula removida da mem�ria.
    Tamanho--;       // Decrementa o tamanho da fila.
    return true;     // Retorna true indicando que o desenfileiramento foi bem-sucedido.
}

// Fun��o que retorna os dados (matr�cula e nota) do elemento na frente da fila, sem remov�-lo.
bool Fila::FrenteFila(TipoDado &Matricula, float &Nota)
{
    // Verifica se a fila est� vazia. Se estiver, retorna false.
    if (Vazia()) return false;

    // Obt�m a matr�cula e a nota do primeiro n� da fila (Frente), sem remov�-lo.
    Matricula = Frente->Matricula;
    Nota = Frente->Nota;
    return true;    // Retorna true indicando que a opera��o foi bem-sucedida.
}

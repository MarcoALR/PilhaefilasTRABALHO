#ifndef FILA_H_INCLUDED    // Verifica se FILA_H_INCLUDED j� foi definido para evitar m�ltiplas inclus�es.
#define FILA_H_INCLUDED    // Define FILA_H_INCLUDED, garantindo que o c�digo a seguir seja inclu�do apenas uma vez.

// Define o tipo de dado que ser� armazenado na fila. Nesse caso, um `int` para a matr�cula.
typedef int TipoDado;

// Estrutura que define uma c�lula da fila, contendo matr�cula, nota e um ponteiro para a pr�xima c�lula.
struct TipoCelulaFila
{
    TipoDado Matricula;     // Armazena a matr�cula do aluno.
    float Nota;             // Armazena a nota do aluno.
    TipoCelulaFila *Prox;   // Ponteiro para a pr�xima c�lula na fila.
};

// Defini��o da classe Fila, que implementa uma fila com opera��es para manipula��o de dados.
class Fila
{
private:
    TipoCelulaFila *Frente;    // Ponteiro para o primeiro elemento (frente) da fila.
    TipoCelulaFila *Tras;      // Ponteiro para o �ltimo elemento (fim) da fila.
    int Tamanho;               // Vari�vel para armazenar o tamanho atual da fila.

public:
    Fila();   // Construtor: inicializa uma fila vazia.
    ~Fila();  // Destrutor: libera a mem�ria alocada para as c�lulas da fila.

    // Verifica se a fila est� vazia (retorna true se estiver vazia, false caso contr�rio).
    bool Vazia();

    // Retorna o tamanho atual da fila (n�mero de elementos).
    int GetTamanho();

    // Adiciona um novo elemento (matr�cula e nota) no final da fila.
    bool Enfileirar(TipoDado Matricula, float Nota);

    // Remove o primeiro elemento da fila e retorna seus valores (matr�cula e nota).
    bool Desenfileirar(TipoDado &Matricula, float &Nota);

    // Retorna o primeiro elemento da fila (matr�cula e nota) sem remov�-lo.
    bool FrenteFila(TipoDado &Matricula, float &Nota);
};

#endif // FILA_H_INCLUDED   // Fim da verifica��o para inclus�o �nica do arquivo.

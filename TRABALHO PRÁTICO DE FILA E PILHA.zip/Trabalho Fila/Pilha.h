#ifndef PILHA_H_INCLUDED   // Verifica se PILHA_H_INCLUDED j� foi definido para evitar m�ltiplas inclus�es.
#define PILHA_H_INCLUDED   // Define PILHA_H_INCLUDED, garantindo que o c�digo a seguir seja inclu�do apenas uma vez.

// Define o tipo de dado que ser� armazenado na pilha. Neste caso, � um `int` representando a matr�cula.
typedef int TipoDado;

// Estrutura que define uma c�lula da pilha, contendo matr�cula, nota e um ponteiro para a pr�xima c�lula.
struct TipoCelulaPilha
{
    TipoDado Matricula;    // Armazena a matr�cula do aluno.
    float Nota;            // Armazena a nota do aluno.
    TipoCelulaPilha *Prox; // Ponteiro para a pr�xima c�lula (abaixo) na pilha.
};

// Defini��o da classe Pilha, que implementa uma pilha com opera��es para manipula��o de dados.
class Pilha
{
private:
    TipoCelulaPilha *Topo; // Ponteiro para o topo da pilha, onde as opera��es de empilhar e desempilhar ocorrem.
    int Tamanho;           // Armazena o tamanho atual da pilha.

public:
    Pilha();   // Construtor: inicializa uma pilha vazia.
    ~Pilha();  // Destrutor: libera a mem�ria alocada para as c�lulas da pilha.

    // Verifica se a pilha est� vazia (retorna true se estiver vazia, false caso contr�rio).
    bool Vazia();

    // Retorna o tamanho atual da pilha (n�mero de elementos).
    int GetTamanho();

    // Adiciona um novo elemento (matr�cula e nota) no topo da pilha.
    bool Empilhar(TipoDado Matricula, float Nota);

    // Remove o elemento do topo da pilha e retorna seus valores (matr�cula e nota).
    bool Desempilhar(TipoDado &Matricula, float &Nota);

    // Adiciona um novo elemento na pilha mantendo a ordem decrescente de notas (e crescente por matr�cula, se as notas forem iguais).
    bool EmpilharOrdenado(TipoDado Matricula, float Nota);
};

#endif // PILHA_H_INCLUDED   // Fim da verifica��o para inclus�o �nica do arquivo.

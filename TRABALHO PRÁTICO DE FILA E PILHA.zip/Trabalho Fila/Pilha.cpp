#include "Pilha.h"      // Inclui o arquivo de cabe�alho da classe Pilha.
#include <iostream>     // Biblioteca padr�o para entrada e sa�da de dados.

// Construtor da classe Pilha: inicializa o ponteiro Topo como nullptr e o tamanho da pilha como 0.
Pilha::Pilha()
{
    Topo = nullptr;
    Tamanho = 0;
}

// Destrutor da classe Pilha: libera a mem�ria de todas as c�lulas (n�s) da pilha.
Pilha::~Pilha()
{
    TipoCelulaPilha *aux;
    // Enquanto houver c�lulas na pilha, desaloca a mem�ria de cada uma.
    while (Topo != nullptr)
    {
        aux = Topo;          // Armazena o ponteiro da c�lula do topo.
        Topo = Topo->Prox;   // Move o ponteiro Topo para o pr�ximo n�.
        delete aux;          // Libera a c�lula anterior da mem�ria.
    }
}

// Verifica se a pilha est� vazia (retorna true se a pilha estiver vazia, ou seja, se o ponteiro Topo for nullptr).
bool Pilha::Vazia()
{
    return (Topo == nullptr);
}

// Retorna o tamanho atual da pilha (quantidade de elementos).
int Pilha::GetTamanho()
{
    return Tamanho;
}

// Fun��o para empilhar um novo elemento (matr�cula e nota) no topo da pilha.
bool Pilha::Empilhar(TipoDado Matricula, float Nota)
{
    // Cria uma nova c�lula (n�) da pilha.
    TipoCelulaPilha *nova = new TipoCelulaPilha;
    nova->Matricula = Matricula;    // Atribui a matr�cula ao novo n�.
    nova->Nota = Nota;              // Atribui a nota ao novo n�.

    // A nova c�lula sempre aponta para o atual topo da pilha.
    nova->Prox = Topo;
    Topo = nova;                    // Atualiza o ponteiro Topo para apontar para o novo n�.
    Tamanho++;                      // Incrementa o tamanho da pilha.
    return true;                    // Retorna true indicando que o empilhamento foi bem-sucedido.
}

// Fun��o para desempilhar (remover) o elemento do topo da pilha.
bool Pilha::Desempilhar(TipoDado &Matricula, float &Nota)
{
    // Verifica se a pilha est� vazia. Se estiver, retorna false.
    if (Vazia()) return false;

    // Armazena o ponteiro da c�lula que est� no topo da pilha.
    TipoCelulaPilha *aux = Topo;
    Matricula = aux->Matricula;    // Obt�m a matr�cula do n� a ser removido.
    Nota = aux->Nota;              // Obt�m a nota do n� a ser removido.
    Topo = Topo->Prox;             // Atualiza o ponteiro Topo para o pr�ximo n�.

    delete aux;        // Libera a c�lula removida da mem�ria.
    Tamanho--;         // Decrementa o tamanho da pilha.
    return true;       // Retorna true indicando que o desempilhamento foi bem-sucedido.
}

// Fun��o para empilhar elementos na pilha mantendo-os em ordem decrescente de nota (e por matr�cula em caso de empate).
bool Pilha::EmpilharOrdenado(TipoDado Matricula, float Nota)
{
    // Cria uma nova c�lula (n�) da pilha.
    TipoCelulaPilha *nova = new TipoCelulaPilha;
    nova->Matricula = Matricula;    // Atribui a matr�cula ao novo n�.
    nova->Nota = Nota;              // Atribui a nota ao novo n�.

    // Se a pilha estiver vazia ou a nota do novo n� for maior que a do topo (ou se a nota for igual e a matr�cula menor),
    // insere o novo n� diretamente no topo.
    if (Vazia() || Topo->Nota < Nota || (Topo->Nota == Nota && Topo->Matricula > Matricula))
    {
        nova->Prox = Topo;
        Topo = nova;
    }
    else
    {
        // Caso contr�rio, percorre a pilha at� encontrar a posi��o correta para inserir o novo n�.
        TipoCelulaPilha *atual = Topo;
        // O loop continua enquanto o pr�ximo n� tiver uma nota maior (ou a nota for igual e a matr�cula menor).
        while (atual->Prox != nullptr && (atual->Prox->Nota > Nota ||
                                          (atual->Prox->Nota == Nota && atual->Prox->Matricula < Matricula)))
        {
            atual = atual->Prox;    // Move para o pr�ximo n�.
        }
        // Insere o novo n� na posi��o correta, ajustando os ponteiros.
        nova->Prox = atual->Prox;
        atual->Prox = nova;
    }

    Tamanho++;   // Incrementa o tamanho da pilha.
    return true; // Retorna true indicando que o empilhamento foi bem-sucedido.
}
